#ifndef TEST_COMMANDS

int close_command_file(void) 
{ return OK; }

#endif
